import { Property } from '../types/property';

export const WHATSAPP_RAW_NUMBER = '09023971419';
// Clean international format for WhatsApp API: 2349023971419
export const WHATSAPP_INTL_NUMBER = '2349023971419';
export const WHATSAPP_DISPLAY_NUMBER = '+234 902 397 1419';

/**
 * Generate a direct WhatsApp click-to-chat URL
 */
export function getWhatsAppUrl(message?: string): string {
  const baseUrl = `https://wa.me/${WHATSAPP_INTL_NUMBER}`;
  if (!message) {
    return baseUrl;
  }
  return `${baseUrl}?text=${encodeURIComponent(message.trim())}`;
}

/**
 * Generate a pre-filled enquiry message for a specific property
 */
export function getPropertyWhatsAppUrl(property: Property): string {
  const priceDisplay = `${property.currency}${property.price.toLocaleString()}${property.listing_type === 'rent' ? '/yr' : ''}`;
  const message = `Hello Angle Real Estate,\n\nI am inquiring about the property:\n*${property.title}*\nLocation: ${property.location}\nPrice: ${priceDisplay}\nReference ID: #${property.id.slice(0, 8)}\n\nPlease provide more information and availability for a physical inspection. Thank you!`;
  
  return getWhatsAppUrl(message);
}

/**
 * Generate direct reply WhatsApp URL for admin replying to a client enquiry
 */
export function getClientReplyWhatsAppUrl(phone: string, clientName: string, propertyTitle?: string): string {
  // Strip non-numeric characters
  let cleanPhone = phone.replace(/\D/g, '');
  if (cleanPhone.startsWith('0') && cleanPhone.length === 11) {
    cleanPhone = '234' + cleanPhone.substring(1);
  }
  
  const greeting = `Hello ${clientName},\n\nThank you for reaching out to Angle Real Estate regarding ${propertyTitle ? `"${propertyTitle}"` : 'your property enquiry'}. We would be delighted to assist you.`;
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(greeting)}`;
}
