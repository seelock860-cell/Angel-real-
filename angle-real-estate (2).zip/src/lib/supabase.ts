import { createClient, SupabaseClient, Session, User } from '@supabase/supabase-js';
import { Property, Enquiry } from '../types/property';
import { INITIAL_PROPERTIES } from '../data/initialProperties';

const STORAGE_KEY_URL = 'angle_supabase_url';
const STORAGE_KEY_ANON = 'angle_supabase_anon_key';
const LOCAL_PROPERTIES_KEY = 'angle_local_properties';
const LOCAL_ENQUIRIES_KEY = 'angle_local_enquiries';

export const DEFAULT_SUPABASE_URL = 'https://bnahzneutohzxgcbobpo.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJuYWh6bmV1dG9oenhnY2JvYnBvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMzNDcxNDAsImV4cCI6MjEwODkyMzE0MH0.pYBOxhtv6u3N112i2CyRnz0PM_8gmapqy22Eqx9p2ic';

export function normalizeSupabaseUrl(rawUrl: string): string {
  if (!rawUrl) return '';
  let url = rawUrl.trim();
  // Strip trailing slashes
  url = url.replace(/\/+$/, '');
  // Strip /rest/v1 or /rest/v1/ if user pasted REST endpoint URL
  url = url.replace(/\/rest\/v1\/?$/i, '');
  return url;
}

// Get current credentials
export function getSavedSupabaseConfig(): { url: string; anonKey: string } {
  const envUrl = (import.meta.env.VITE_SUPABASE_URL as string) || '';
  const envKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string) || '';

  const savedUrl = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY_URL) : null;
  const savedKey = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY_ANON) : null;

  const url = normalizeSupabaseUrl(savedUrl || envUrl || DEFAULT_SUPABASE_URL);
  const anonKey = (savedKey || envKey || DEFAULT_SUPABASE_ANON_KEY).trim();

  return { url, anonKey };
}

// Check if credentials are set
export function isSupabaseConfigured(): boolean {
  const { url, anonKey } = getSavedSupabaseConfig();
  return Boolean(url && anonKey && url.startsWith('http') && anonKey.length > 20);
}

// Create or get Supabase Client instance
let supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  const { url, anonKey } = getSavedSupabaseConfig();
  if (!isSupabaseConfigured()) {
    return null;
  }

  if (!supabaseInstance) {
    try {
      supabaseInstance = createClient(url, anonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true,
        }
      });
    } catch (err) {
      console.error('Failed to initialize Supabase client:', err);
      return null;
    }
  }

  return supabaseInstance;
}

// Update Supabase configuration dynamically from Admin Dashboard
export function updateSupabaseConfig(url: string, anonKey: string): { success: boolean; message: string } {
  try {
    const cleanUrl = normalizeSupabaseUrl(url);
    const cleanKey = anonKey.trim();

    if (!cleanUrl || !cleanKey) {
      localStorage.removeItem(STORAGE_KEY_URL);
      localStorage.removeItem(STORAGE_KEY_ANON);
      supabaseInstance = null;
      return { success: true, message: 'Supabase configuration removed. Running in offline/local mode.' };
    }

    if (!cleanUrl.startsWith('https://') && !cleanUrl.startsWith('http://')) {
      return { success: false, message: 'Supabase URL must start with https://' };
    }

    localStorage.setItem(STORAGE_KEY_URL, cleanUrl);
    localStorage.setItem(STORAGE_KEY_ANON, cleanKey);
    supabaseInstance = createClient(cleanUrl, cleanKey);
    return { success: true, message: 'Supabase configuration saved successfully!' };
  } catch (err: any) {
    return { success: false, message: err.message || 'Error updating configuration' };
  }
}

// Test live Supabase connection
export async function testSupabaseConnection(url?: string, anonKey?: string): Promise<{ success: boolean; message: string }> {
  try {
    const rawTargetUrl = url || getSavedSupabaseConfig().url;
    const targetUrl = normalizeSupabaseUrl(rawTargetUrl);
    const targetKey = (anonKey || getSavedSupabaseConfig().anonKey).trim();

    if (!targetUrl || !targetKey) {
      return { success: false, message: 'Please provide both Supabase URL and Publishable API Key.' };
    }

    const testClient = createClient(targetUrl, targetKey);
    // Try pinging the properties table or system endpoint
    const { error } = await testClient.from('properties').select('id').limit(1);

    if (error) {
      // If table doesn't exist yet, it's connected to Supabase but schema is missing
      if (error.code === '42P01') {
        return { 
          success: true, 
          message: 'Connected to Supabase project! Note: The "properties" table has not been created yet in SQL editor. Please run the provided SQL script.' 
        };
      }
      return { success: false, message: `Supabase Error: ${error.message} (Code: ${error.code})` };
    }

    return { success: true, message: 'Successfully connected to Supabase backend database!' };
  } catch (err: any) {
    return { success: false, message: err.message || 'Failed to connect to Supabase.' };
  }
}

// Local storage storage fallback helpers
function getLocalProperties(): Property[] {
  if (typeof window === 'undefined') return INITIAL_PROPERTIES;
  const raw = localStorage.getItem(LOCAL_PROPERTIES_KEY);
  if (!raw) {
    localStorage.setItem(LOCAL_PROPERTIES_KEY, JSON.stringify(INITIAL_PROPERTIES));
    return INITIAL_PROPERTIES;
  }
  try {
    return JSON.parse(raw);
  } catch {
    return INITIAL_PROPERTIES;
  }
}

function setLocalProperties(properties: Property[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(LOCAL_PROPERTIES_KEY, JSON.stringify(properties));
  }
}

function getLocalEnquiries(): Enquiry[] {
  if (typeof window === 'undefined') return [];
  const raw = localStorage.getItem(LOCAL_ENQUIRIES_KEY);
  if (!raw) {
    const sampleEnquiries: Enquiry[] = [
      {
        id: 'enq-sample-1',
        property_id: 'prop-lekki-villa-01',
        property_title: 'The Obsidian Grand Waterfront Villa',
        customer_name: 'Dr. Babatunde Adeleke',
        customer_email: 'babatunde.adeleke@example.com',
        customer_phone: '08034567890',
        message: 'Interested in a private physical inspection next Tuesday afternoon. Please confirm availability.',
        status: 'new',
        created_at: new Date(Date.now() - 3600000 * 4).toISOString()
      },
      {
        id: 'enq-sample-2',
        property_id: 'prop-vi-penthouse-03',
        property_title: 'Azure Sky Penthouse with Marina Panorama',
        customer_name: 'Mrs. Folashade Alakija',
        customer_email: 'folashade@corporate.ng',
        customer_phone: '08123456789',
        message: 'We are looking to lease this for our executive team for a 2-year lease. Can we discuss payment terms?',
        status: 'contacted',
        created_at: new Date(Date.now() - 3600000 * 28).toISOString()
      }
    ];
    localStorage.setItem(LOCAL_ENQUIRIES_KEY, JSON.stringify(sampleEnquiries));
    return sampleEnquiries;
  }
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function setLocalEnquiries(enquiries: Enquiry[]): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(LOCAL_ENQUIRIES_KEY, JSON.stringify(enquiries));
  }
}

// ----------------- DATA OPERATIONS -----------------

/**
 * Fetch all properties
 */
export async function fetchProperties(): Promise<{ data: Property[]; isFromSupabase: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('properties')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data && data.length > 0) {
        return { data: data as Property[], isFromSupabase: true };
      }

      // If table exists in Supabase but has 0 records, auto-seed initial properties
      if (!error && data && data.length === 0) {
        await seedPropertiesToSupabase();
        const { data: seededData } = await supabase
          .from('properties')
          .select('*')
          .order('created_at', { ascending: false });

        if (seededData && seededData.length > 0) {
          return { data: seededData as Property[], isFromSupabase: true };
        }
      }

      if (error) {
        console.warn('Supabase fetch failed, falling back to local dataset:', error.message);
      }
    } catch (err: any) {
      console.warn('Supabase exception, falling back to local dataset:', err);
    }
  }

  // Fallback to local properties
  return { data: getLocalProperties(), isFromSupabase: false };
}

/**
 * Save or update a property
 */
export async function saveProperty(property: Property): Promise<{ success: boolean; data?: Property; error?: string }> {
  const supabase = getSupabaseClient();

  if (supabase) {
    try {
      const payload = {
        ...property,
        updated_at: new Date().toISOString()
      };

      const { data, error } = await supabase
        .from('properties')
        .upsert(payload)
        .select()
        .single();

      if (error) {
        console.error('Supabase save error:', error);
        return { success: false, error: error.message };
      }

      // Also update local cache
      const current = getLocalProperties();
      const idx = current.findIndex(p => p.id === property.id);
      if (idx >= 0) {
        current[idx] = data as Property;
      } else {
        current.unshift(data as Property);
      }
      setLocalProperties(current);

      return { success: true, data: data as Property };
    } catch (err: any) {
      console.error('Supabase exception in saveProperty:', err);
      return { success: false, error: err.message };
    }
  }

  // Local storage save
  const current = getLocalProperties();
  const idx = current.findIndex(p => p.id === property.id);
  const updatedProperty = {
    ...property,
    updated_at: new Date().toISOString()
  };

  if (idx >= 0) {
    current[idx] = updatedProperty;
  } else {
    current.unshift(updatedProperty);
  }
  setLocalProperties(current);

  return { success: true, data: updatedProperty };
}

/**
 * Delete a property
 */
export async function deleteProperty(propertyId: string): Promise<{ success: boolean; error?: string }> {
  const supabase = getSupabaseClient();

  if (supabase) {
    try {
      const { error } = await supabase
        .from('properties')
        .delete()
        .eq('id', propertyId);

      if (error) {
        return { success: false, error: error.message };
      }
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  // Also remove from local
  const current = getLocalProperties();
  const filtered = current.filter(p => p.id !== propertyId);
  setLocalProperties(filtered);

  return { success: true };
}

/**
 * Fetch all enquiries
 */
export async function fetchEnquiries(): Promise<{ data: Enquiry[]; isFromSupabase: boolean; error?: string }> {
  const supabase = getSupabaseClient();

  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('enquiries')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data) {
        return { data: data as Enquiry[], isFromSupabase: true };
      }
    } catch (err) {
      console.warn('Enquiries fetch exception:', err);
    }
  }

  return { data: getLocalEnquiries(), isFromSupabase: false };
}

/**
 * Submit customer enquiry
 */
export async function submitEnquiry(enquiry: Omit<Enquiry, 'id' | 'created_at' | 'status'>): Promise<{ success: boolean; data?: Enquiry; error?: string }> {
  const newEnquiry: Enquiry = {
    id: `enq-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    ...enquiry,
    status: 'new',
    created_at: new Date().toISOString()
  };

  const supabase = getSupabaseClient();

  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('enquiries')
        .insert(newEnquiry)
        .select()
        .single();

      if (!error && data) {
        // Also update local list
        const local = getLocalEnquiries();
        local.unshift(data as Enquiry);
        setLocalEnquiries(local);
        return { success: true, data: data as Enquiry };
      }
    } catch (err: any) {
      console.warn('Supabase enquiry insert failed, saving locally:', err);
    }
  }

  const local = getLocalEnquiries();
  local.unshift(newEnquiry);
  setLocalEnquiries(local);

  return { success: true, data: newEnquiry };
}

/**
 * Update enquiry status
 */
export async function updateEnquiryStatus(enquiryId: string, status: 'new' | 'contacted' | 'closed'): Promise<{ success: boolean; error?: string }> {
  const supabase = getSupabaseClient();

  if (supabase) {
    try {
      const { error } = await supabase
        .from('enquiries')
        .update({ status })
        .eq('id', enquiryId);

      if (error) {
        return { success: false, error: error.message };
      }
    } catch (err: any) {
      console.warn('Supabase enquiry status update error:', err);
    }
  }

  const local = getLocalEnquiries();
  const found = local.find(e => e.id === enquiryId);
  if (found) {
    found.status = status;
    setLocalEnquiries(local);
  }

  return { success: true };
}

/**
 * Seed / Push initial properties to connected Supabase instance
 */
export async function seedPropertiesToSupabase(): Promise<{ success: boolean; count: number; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) {
    return { success: false, count: 0, error: 'Supabase client is not configured yet.' };
  }

  try {
    const propertiesToSync = getLocalProperties();
    const { data, error } = await supabase
      .from('properties')
      .upsert(propertiesToSync, { onConflict: 'id' })
      .select();

    if (error) {
      return { success: false, count: 0, error: error.message };
    }

    return { success: true, count: data ? data.length : propertiesToSync.length };
  } catch (err: any) {
    return { success: false, count: 0, error: err.message };
  }
}

/**
 * Restore sample properties in local storage
 */
export function resetToSampleProperties(): Property[] {
  setLocalProperties(INITIAL_PROPERTIES);
  return INITIAL_PROPERTIES;
}
