import React from 'react';
import { MessageCircle, PhoneCall, ShieldCheck, Mail, MapPin } from 'lucide-react';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_NUMBER, WHATSAPP_RAW_NUMBER } from '../lib/whatsapp';

interface FooterProps {
  onOpenAdmin?: () => void;
  onNavigate: (sectionId: string) => void;
  onFilterChange: (type: 'all' | 'buy' | 'rent') => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onFilterChange }) => {
  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-900 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-900">
          {/* Brand Bio */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
                <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 stroke-white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3 21L21 21" />
                  <path d="M3 21L3 5" />
                  <path d="M3 5L21 21" />
                  <circle cx="12" cy="12" r="1.5" fill="white" />
                </svg>
              </div>
              <div>
                <span className="font-extrabold tracking-tight text-lg text-white font-sans block">
                  ANGLE <span className="text-blue-500">REAL ESTATE</span>
                </span>
                <span className="text-[10px] tracking-wider uppercase text-slate-400">
                  Find a Place to Call Home
                </span>
              </div>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              ANGLE REAL ESTATE is a premier full-service property firm specializing in luxury residential acquisitions, leasing management, and institutional real estate advisory across Nigeria.
            </p>

            <div className="pt-1">
              <a
                href={getWhatsAppUrl("Hello Angle Real Estate, I would like to speak with an advisor.")}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 rounded-lg hover:bg-emerald-600/30 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp: {WHATSAPP_DISPLAY_NUMBER}</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm tracking-wide">Quick Navigation</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onNavigate('hero')} className="hover:text-white transition-colors cursor-pointer">
                  Homepage
                </button>
              </li>
              <li>
                <button onClick={() => { onFilterChange('all'); onNavigate('properties'); }} className="hover:text-white transition-colors cursor-pointer">
                  All Properties
                </button>
              </li>
              <li>
                <button onClick={() => { onFilterChange('buy'); onNavigate('properties'); }} className="hover:text-white transition-colors cursor-pointer">
                  Properties for Sale
                </button>
              </li>
              <li>
                <button onClick={() => { onFilterChange('rent'); onNavigate('properties'); }} className="hover:text-white transition-colors cursor-pointer">
                  Properties for Rent
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('sell-section')} className="hover:text-white transition-colors cursor-pointer">
                  List Your Property
                </button>
              </li>
            </ul>
          </div>

          {/* Prime Locations */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm tracking-wide">Prime Locations</h4>
            <ul className="space-y-2 text-slate-400">
              <li>Lekki Phase 1, Lagos</li>
              <li>Banana Island, Ikoyi</li>
              <li>Victoria Island (VI), Lagos</li>
              <li>Maitama District, Abuja</li>
              <li>Guzape Diplomatic Zone</li>
              <li>Ikeja GRA, Lagos</li>
            </ul>
          </div>

          {/* Contact Direct */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm tracking-wide">Contact Desk</h4>
            <div className="space-y-2 text-slate-400">
              <div className="flex items-center gap-2">
                <PhoneCall className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span>{WHATSAPP_RAW_NUMBER}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span>info@anglerealestate.com</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                <span>Admiralty Way, Lekki Phase 1, Lagos</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-400">
          <p>© {new Date().getFullYear()} ANGLE REAL ESTATE. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span>Corporate Registration RC: 1849204</span>
            <span>·</span>
            <span>Real Estate Verified Firm</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
