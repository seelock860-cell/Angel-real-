import React, { useState } from 'react';
import { X, Bed, Bath, Square, MapPin, MessageCircle, Share2, Check, Send, CheckCircle2, Phone, Calendar, ShieldCheck } from 'lucide-react';
import { Property, Enquiry } from '../types/property';
import { getPropertyWhatsAppUrl, WHATSAPP_DISPLAY_NUMBER } from '../lib/whatsapp';
import { submitEnquiry } from '../lib/supabase';

interface PropertyDetailModalProps {
  property: Property | null;
  onClose: () => void;
}

export const PropertyDetailModal: React.FC<PropertyDetailModalProps> = ({ property, onClose }) => {
  if (!property) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [copiedLink, setCopiedLink] = useState(false);

  // Enquiry form state
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formMessage, setFormMessage] = useState(`Hello, I would like to schedule a physical viewing of ${property.title}.`);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Mortgage/payment calculator state
  const isRent = property.listing_type === 'rent';
  const downPaymentPercent = 20;
  const downPaymentAmount = Math.round((property.price * downPaymentPercent) / 100);
  const loanAmount = property.price - downPaymentAmount;
  // Estimated 15-year mortgage monthly at ~18% interest rate in Nigeria
  const monthlyMortgage = Math.round((loanAmount * 0.016) + (loanAmount / (15 * 12)));

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleSubmitEnquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formPhone) return;

    setIsSubmitting(true);
    try {
      await submitEnquiry({
        property_id: property.id,
        property_title: property.title,
        customer_name: formName,
        customer_email: formEmail || 'Not provided',
        customer_phone: formPhone,
        message: formMessage
      });
      setSubmitSuccess(true);
    } catch (err) {
      console.error('Failed to submit enquiry:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const images = property.images && property.images.length > 0 
    ? property.images 
    : ['/src/assets/images/hero_angle_property_1793350587000.jpg'];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col my-auto border border-slate-200">
        {/* Top Header Strip */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 text-xs font-bold rounded uppercase tracking-wider bg-blue-600">
              For {property.listing_type === 'rent' ? 'Rent' : 'Sale'}
            </span>
            <span className="text-xs text-slate-400">Ref: #{property.id.slice(0, 10)}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-xs flex items-center gap-1 cursor-pointer"
              title="Copy property link"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{copiedLink ? 'Copied' : 'Share'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body Content */}
        <div className="overflow-y-auto p-6 space-y-6 flex-1">
          {/* Main Gallery Display */}
          <div className="space-y-3">
            <div className="relative aspect-[16/9] w-full rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
              <img
                src={images[activeImageIndex]}
                alt={property.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute bottom-3 left-3 bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded text-white text-xs font-medium">
                Photo {activeImageIndex + 1} of {images.length}
              </div>
            </div>

            {/* Thumbnail selector if multiple images */}
            {images.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-20 h-14 rounded-lg overflow-hidden shrink-0 border-2 transition-all cursor-pointer ${
                      activeImageIndex === idx ? 'border-blue-600 scale-102' : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`Thumb ${idx}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Title & Price Header */}
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-6 border-b border-slate-100">
            <div>
              <div className="text-xs font-semibold text-blue-700 uppercase tracking-wider mb-1">
                {property.property_type} · {property.city || property.location}
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight">
                {property.title}
              </h2>
              <div className="flex items-center gap-1.5 text-sm text-slate-500 mt-2">
                <MapPin className="w-4 h-4 text-blue-600 shrink-0" />
                <span>{property.location}</span>
              </div>
            </div>

            <div className="text-left md:text-right shrink-0">
              <div className="text-2xl sm:text-3xl font-black text-blue-900 tabular-nums">
                {property.currency}{property.price.toLocaleString()}
                {isRent && <span className="text-sm font-normal text-slate-500"> /year</span>}
              </div>
              <span className="text-xs text-slate-500 block mt-1">
                Status: <strong className="text-emerald-700 capitalize">{property.status}</strong>
              </span>
            </div>
          </div>

          {/* Key Specs Bar */}
          <div className="grid grid-cols-3 gap-3 bg-slate-50 rounded-xl p-4 border border-slate-200/80 text-center">
            {property.bedrooms > 0 && (
              <div className="flex flex-col items-center justify-center">
                <Bed className="w-5 h-5 text-blue-700 mb-1" />
                <span className="text-sm font-bold text-slate-900">{property.bedrooms}</span>
                <span className="text-xs text-slate-500">Bedrooms</span>
              </div>
            )}
            {property.bathrooms > 0 && (
              <div className="flex flex-col items-center justify-center border-x border-slate-200">
                <Bath className="w-5 h-5 text-blue-700 mb-1" />
                <span className="text-sm font-bold text-slate-900">{property.bathrooms}</span>
                <span className="text-xs text-slate-500">Bathrooms</span>
              </div>
            )}
            {property.area_sqm > 0 && (
              <div className="flex flex-col items-center justify-center">
                <Square className="w-5 h-5 text-blue-700 mb-1" />
                <span className="text-sm font-bold text-slate-900 tabular-nums">{property.area_sqm} m²</span>
                <span className="text-xs text-slate-500">Plot / Area</span>
              </div>
            )}
          </div>

          {/* Property Description */}
          <div>
            <h4 className="text-base font-bold text-slate-900 mb-2">Property Overview</h4>
            <p className="text-slate-600 text-sm leading-relaxed whitespace-pre-line">
              {property.description}
            </p>
          </div>

          {/* Features & Amenities List */}
          {property.features && property.features.length > 0 && (
            <div>
              <h4 className="text-base font-bold text-slate-900 mb-3">Amenities & Security Features</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {property.features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Financial Breakdown / Mortgage Guide */}
          <div className="bg-blue-50/60 rounded-xl p-5 border border-blue-100">
            <h4 className="text-sm font-bold text-blue-950 mb-1">
              {isRent ? 'Rental Payment Structure' : 'Estimated Mortgage Breakdown'}
            </h4>
            <p className="text-xs text-slate-600 mb-4">
              {isRent 
                ? 'Standard annual lease terms with professional documentation handled directly by Angle Real Estate.' 
                : 'Sample 20% down payment financing schedule. Contact our sales advisory for bank partnership options.'}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div className="bg-white p-3 rounded-lg border border-blue-100">
                <span className="text-slate-500 block">Listing Value</span>
                <span className="font-bold text-slate-900 text-sm tabular-nums">
                  {property.currency}{property.price.toLocaleString()}
                </span>
              </div>
              <div className="bg-white p-3 rounded-lg border border-blue-100">
                <span className="text-slate-500 block">{isRent ? 'Caution Deposit (10%)' : 'Down Payment (20%)'}</span>
                <span className="font-bold text-slate-900 text-sm tabular-nums">
                  {property.currency}{isRent ? Math.round(property.price * 0.1).toLocaleString() : downPaymentAmount.toLocaleString()}
                </span>
              </div>
              <div className="bg-white p-3 rounded-lg border border-blue-100 col-span-2 sm:col-span-1">
                <span className="text-slate-500 block">{isRent ? 'Agency & Legal (10%)' : 'Est. Monthly Finance'}</span>
                <span className="font-bold text-blue-700 text-sm tabular-nums">
                  {property.currency}{isRent ? Math.round(property.price * 0.1).toLocaleString() : monthlyMortgage.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Contact & Enquiry Box */}
          <div className="bg-slate-900 text-white rounded-xl p-6 border border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-slate-800">
              <div>
                <span className="text-xs uppercase tracking-wider text-blue-400 font-semibold block">
                  Direct Agent Inspection
                </span>
                <h3 className="text-lg font-bold text-white">Interested in this property?</h3>
                <p className="text-xs text-slate-300 mt-1">
                  Connect instantly via WhatsApp or leave your details for a scheduled callback.
                </p>
              </div>

              <a
                href={getPropertyWhatsAppUrl(property)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold rounded-lg shadow-md transition-all shrink-0 cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 fill-white/20" />
                <span>Enquire via WhatsApp</span>
              </a>
            </div>

            {/* In-app Enquiry Form */}
            {submitSuccess ? (
              <div className="bg-emerald-950/80 border border-emerald-600/40 rounded-lg p-4 text-center">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-white">Enquiry Received!</h4>
                <p className="text-xs text-slate-300 mt-1 mb-3">
                  An Angle Real Estate agent will contact you shortly on {formPhone}.
                </p>
                <a
                  href={getPropertyWhatsAppUrl(property)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 font-semibold"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Click here to also continue the conversation on WhatsApp</span>
                </a>
              </div>
            ) : (
              <form onSubmit={handleSubmitEnquiry} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-300 mb-1">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Babatunde Lawal"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-300 mb-1">Phone / WhatsApp Number *</label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 08012345678"
                      value={formPhone}
                      onChange={(e) => setFormPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-300 mb-1">Email Address</label>
                  <input
                    type="email"
                    placeholder="e.g. babatunde@example.com"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-300 mb-1">Inspection Note / Message</label>
                  <textarea
                    rows={2}
                    value={formMessage}
                    onChange={(e) => setFormMessage(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Sending Enquiry...' : 'Schedule Inspection Callback'}</span>
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Bottom Persistent Bar */}
        <div className="px-6 py-3.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Angle Verified Property Title</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-lg transition-colors cursor-pointer"
            >
              Close
            </button>
            <a
              href={getPropertyWhatsAppUrl(property)}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-white/20" />
              <span>WhatsApp Agent</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
