import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_NUMBER } from '../lib/whatsapp';

export const WhatsAppFloat: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {/* Mini Popover Callout */}
      {showTooltip && (
        <div className="mb-3 max-w-xs bg-white text-slate-900 rounded-xl shadow-2xl p-4 border border-slate-200 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="flex items-start justify-between gap-2 mb-1.5">
            <span className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Angle Real Estate Support
            </span>
            <button
              onClick={() => setShowTooltip(false)}
              className="text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed mb-3">
            Looking for a property in Lagos or Abuja? Chat directly with an Angle Real Estate advisor on WhatsApp!
          </p>
          <a
            href={getWhatsAppUrl("Hello Angle Real Estate, I would like to chat with an agent regarding property inquiries.")}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-lg transition-colors"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Chat {WHATSAPP_DISPLAY_NUMBER}</span>
          </a>
        </div>
      )}

      {/* Floating Button */}
      <a
        href={getWhatsAppUrl("Hello Angle Real Estate, I am visiting your website and have an enquiry.")}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setShowTooltip(true)}
        className="relative flex items-center justify-center w-14 h-14 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full shadow-2xl shadow-emerald-700/40 hover:scale-105 transition-all duration-300 group cursor-pointer"
        aria-label="Chat on WhatsApp"
        title="Chat with Angle Real Estate on WhatsApp (09023971419)"
      >
        <MessageCircle className="w-7 h-7 fill-white" />
        
        {/* Subtle ping indicator */}
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-400 border-2 border-white" />
        </span>
      </a>
    </div>
  );
};
