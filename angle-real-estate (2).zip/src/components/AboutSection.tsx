import React from 'react';
import { ShieldCheck, Award, Users, Key, CheckCircle, ArrowRight } from 'lucide-react';
import { getWhatsAppUrl } from '../lib/whatsapp';

interface AboutSectionProps {
  onExploreClick: () => void;
  onOpenSellModal: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onExploreClick, onOpenSellModal }) => {
  return (
    <section id="about" className="py-20 bg-slate-900 text-white relative overflow-hidden">
      {/* Subtle geometric background accents */}
      <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-blue-600/10 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-blue-500/10 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column: Brand Story */}
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950 border border-blue-800 text-blue-300 text-xs font-semibold uppercase tracking-wider">
              <span>Why Angle Real Estate</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight font-sans text-balance">
              Building Wealth and Security Through Exceptional Real Estate.
            </h2>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Founded on the pillars of integrity, discretion, and market mastery, Angle Real Estate has established itself as Nigeria’s trusted advisory for ultra-luxury residential properties and high-yield commercial assets.
            </p>

            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
              Whether you are acquiring a generational waterfront residence in Ikoyi, securing an executive lease in Victoria Island, or listing a prime residential development, our dedicated property consultants provide white-glove guidance at every step.
            </p>

            {/* Value Pillars List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="flex items-start gap-3 bg-slate-800/60 p-4 rounded-xl border border-slate-800">
                <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-white">Verified Legal Titles</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Governor’s Consent, C of O, and title searches vetted by top real estate solicitors.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-slate-800/60 p-4 rounded-xl border border-slate-800">
                <Award className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-white">Direct WhatsApp Concierge</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Instant response, schedule physical or virtual 4K walkthroughs on demand.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-slate-800/60 p-4 rounded-xl border border-slate-800">
                <Users className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-white">Private Off-Market Network</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Exclusive access to unlisted luxury properties in Banana Island, Maitama, and Asokoro.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-slate-800/60 p-4 rounded-xl border border-slate-800">
                <Key className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-white">End-to-End Closing</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    From initial physical inspection to escrow, stamp duties, and key handover.
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-4 flex flex-wrap items-center gap-4">
              <button
                onClick={onExploreClick}
                className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-sm transition-all cursor-pointer"
              >
                <span>Browse Available Listings</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenSellModal}
                className="inline-flex items-center gap-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white text-xs sm:text-sm font-semibold rounded-lg border border-slate-700 transition-all cursor-pointer"
              >
                <span>List With Us</span>
              </button>
            </div>
          </div>

          {/* Right Column: High-Impact Visual Composition */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-700/80 shadow-2xl aspect-[4/3]">
              <img
                src="/src/assets/images/villa_lekki_facade_1793350588492.jpg"
                alt="Angle Real Estate Luxury Villa"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-slate-950/90 backdrop-blur-md border border-slate-800 text-white">
                <div className="text-xs text-blue-400 font-semibold uppercase tracking-wider mb-1">
                  Private Enclave Portfolio
                </div>
                <div className="text-sm font-bold">
                  Exclusive Luxury Mansions & Penthouse Developments
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  Admiralty Way, Lekki & Zone A, Banana Island, Lagos
                </div>
              </div>
            </div>

            {/* Floating stat card */}
            <div className="absolute -bottom-6 -left-6 hidden sm:block bg-white text-slate-900 p-5 rounded-xl shadow-2xl border border-slate-100 max-w-xs">
              <div className="text-3xl font-extrabold text-blue-700 font-sans tabular-nums">
                ₦18.4 Billion+
              </div>
              <div className="text-xs text-slate-600 mt-1 font-medium">
                Verified luxury property transactions facilitated in prime Lagos and Abuja corridors.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
