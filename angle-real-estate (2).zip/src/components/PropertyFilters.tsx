import React from 'react';
import { Search, RotateCcw, SlidersHorizontal, ArrowUpDown } from 'lucide-react';
import { PropertyFilterState } from '../types/property';
import { PROPERTY_TYPES } from '../data/initialProperties';

interface PropertyFiltersProps {
  filter: PropertyFilterState;
  onFilterChange: (updates: Partial<PropertyFilterState>) => void;
  onReset: () => void;
  totalResults: number;
}

export const PropertyFilters: React.FC<PropertyFiltersProps> = ({
  filter,
  onFilterChange,
  onReset,
  totalResults
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 mb-8 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        {/* Left: Tabbed Filter for Listing Type (Buy, Rent, All) */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg self-start">
          <button
            onClick={() => onFilterChange({ listing_type: 'all' })}
            className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
              filter.listing_type === 'all'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Listings
          </button>
          <button
            onClick={() => onFilterChange({ listing_type: 'buy' })}
            className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
              filter.listing_type === 'buy'
                ? 'bg-blue-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            For Sale (Buy)
          </button>
          <button
            onClick={() => onFilterChange({ listing_type: 'rent' })}
            className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
              filter.listing_type === 'rent'
                ? 'bg-blue-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            For Rent
          </button>
        </div>

        {/* Right: Results Count + Sort & Reset */}
        <div className="flex items-center justify-between md:justify-end gap-3 text-xs">
          <span className="text-slate-500 font-medium">
            Showing <strong className="text-slate-900 font-semibold tabular-nums">{totalResults}</strong> properties
          </span>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-slate-600 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={filter.sort_by}
                onChange={(e) => onFilterChange({ sort_by: e.target.value as any })}
                className="bg-transparent border-none text-slate-700 text-xs font-medium focus:outline-none cursor-pointer"
              >
                <option value="featured">Featured First</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="newest">Newest Listed</option>
              </select>
            </div>

            <button
              onClick={onReset}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Reset Filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Filter Row: Location / Search Input, Property Type, Bedrooms, Max Price */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-4">
        {/* Keyword / Location Search */}
        <div className="relative">
          <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search location (Lekki, Ikoyi, Abuja...)"
            value={filter.search}
            onChange={(e) => onFilterChange({ search: e.target.value })}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:ring-2 focus:ring-blue-600 focus:outline-none transition-all"
          />
        </div>

        {/* Property Type Dropdown */}
        <div>
          <select
            value={filter.property_type}
            onChange={(e) => onFilterChange({ property_type: e.target.value })}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-600 focus:outline-none transition-all cursor-pointer"
          >
            {PROPERTY_TYPES.map((type) => (
              <option key={type} value={type === 'All Types' ? '' : type}>
                {type}
              </option>
            ))}
          </select>
        </div>

        {/* Bedrooms Filter */}
        <div>
          <select
            value={filter.bedrooms}
            onChange={(e) => {
              const val = e.target.value;
              onFilterChange({ bedrooms: val === 'all' ? 'all' : Number(val) });
            }}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-600 focus:outline-none transition-all cursor-pointer"
          >
            <option value="all">Bedrooms: Any</option>
            <option value="1">1+ Bedroom</option>
            <option value="2">2+ Bedrooms</option>
            <option value="3">3+ Bedrooms</option>
            <option value="4">4+ Bedrooms</option>
            <option value="5">5+ Bedrooms</option>
          </select>
        </div>

        {/* Max Price Filter */}
        <div>
          <select
            value={filter.max_price}
            onChange={(e) => {
              const val = e.target.value;
              onFilterChange({ max_price: val === 'all' ? 'all' : Number(val) });
            }}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-600 focus:outline-none transition-all cursor-pointer"
          >
            <option value="all">Max Budget: Any</option>
            <option value="50000000">Up to ₦50M</option>
            <option value="100000000">Up to ₦100M</option>
            <option value="400000000">Up to ₦400M</option>
            <option value="800000000">Up to ₦800M</option>
            <option value="1500000000">Up to ₦1.5 Billion</option>
          </select>
        </div>
      </div>
    </div>
  );
};
