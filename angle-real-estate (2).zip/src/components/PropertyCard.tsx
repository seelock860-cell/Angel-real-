import React from 'react';
import { Bed, Bath, Square, MapPin, MessageCircle, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { Property } from '../types/property';
import { getPropertyWhatsAppUrl } from '../lib/whatsapp';

interface PropertyCardProps {
  property: Property;
  onViewDetails: (property: Property) => void;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, onViewDetails }) => {
  const formattedPrice = `${property.currency || '₦'}${property.price.toLocaleString()}`;
  const isRent = property.listing_type === 'rent';
  const mainImage = property.images && property.images.length > 0 
    ? property.images[0] 
    : '/src/assets/images/hero_angle_property_1793350587000.jpg';

  return (
    <div className="group bg-white rounded-xl border border-slate-200/90 overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col">
      {/* Property Image Container */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-100">
        <img
          src={mainImage}
          alt={property.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            // Fallback image in case of load issues
            (e.target as HTMLImageElement).src = '/src/assets/images/hero_angle_property_1793350587000.jpg';
          }}
        />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex items-center gap-2">
          <span className={`px-2.5 py-1 text-xs font-bold rounded-md uppercase tracking-wider text-white shadow-sm ${
            isRent ? 'bg-slate-900' : 'bg-blue-700'
          }`}>
            For {property.listing_type === 'rent' ? 'Rent' : 'Sale'}
          </span>
          {property.featured && (
            <span className="px-2.5 py-1 text-xs font-semibold rounded-md bg-amber-500 text-white shadow-sm">
              Featured
            </span>
          )}
        </div>

        {/* Status Badge if not available */}
        {property.status !== 'available' && (
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center">
            <span className="px-4 py-1.5 bg-rose-600 text-white font-bold text-sm uppercase rounded tracking-wider shadow-lg">
              {property.status}
            </span>
          </div>
        )}

        {/* Property Category Tag */}
        <div className="absolute bottom-3 right-3">
          <span className="px-2.5 py-1 text-xs font-medium rounded-md bg-slate-950/80 backdrop-blur-md text-white">
            {property.property_type}
          </span>
        </div>
      </div>

      {/* Property Content Area */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Price */}
          <div className="flex items-baseline justify-between mb-2">
            <div className="text-xl sm:text-2xl font-extrabold text-blue-900 font-sans tabular-nums">
              {formattedPrice}
              {isRent && <span className="text-xs font-normal text-slate-500 ml-1">/year</span>}
            </div>
          </div>

          {/* Title */}
          <h3 
            onClick={() => onViewDetails(property)}
            className="text-base font-bold text-slate-900 line-clamp-1 hover:text-blue-700 transition-colors cursor-pointer mb-2"
            title={property.title}
          >
            {property.title}
          </h3>

          {/* Location */}
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-4 line-clamp-1">
            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="truncate">{property.location}</span>
          </div>

          {/* Clean Unboxed Metadata Specs: Bedrooms, Bathrooms, Area */}
          <div className="flex items-center gap-4 text-xs font-medium text-slate-600 py-3 border-y border-slate-100 mb-4">
            {property.bedrooms > 0 && (
              <div className="flex items-center gap-1.5">
                <Bed className="w-4 h-4 text-blue-600" />
                <span>{property.bedrooms} Beds</span>
              </div>
            )}
            {property.bathrooms > 0 && (
              <div className="flex items-center gap-1.5">
                <Bath className="w-4 h-4 text-blue-600" />
                <span>{property.bathrooms} Baths</span>
              </div>
            )}
            {property.area_sqm > 0 && (
              <div className="flex items-center gap-1.5">
                <Square className="w-4 h-4 text-blue-600" />
                <span className="tabular-nums">{property.area_sqm} m²</span>
              </div>
            )}
          </div>

          {/* Key Feature Highlight Pill */}
          {property.features && property.features.length > 0 && (
            <div className="flex items-center gap-1 text-[11px] text-slate-500 mb-4">
              <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
              <span className="truncate">{property.features[0]}</span>
              {property.features.length > 1 && (
                <span className="text-slate-400">+{property.features.length - 1} more</span>
              )}
            </div>
          )}
        </div>

        {/* Action Buttons: WhatsApp Enquiry + View Details */}
        <div className="pt-2 grid grid-cols-2 gap-2">
          <button
            onClick={() => onViewDetails(property)}
            className="w-full inline-flex items-center justify-center gap-1 py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            <span>Details</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>

          <a
            href={getPropertyWhatsAppUrl(property)}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full inline-flex items-center justify-center gap-1.5 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm hover:shadow transition-all cursor-pointer"
            title="Chat with Angle Real Estate on WhatsApp regarding this property"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-white/20" />
            <span>Enquire</span>
          </a>
        </div>
      </div>
    </div>
  );
};
