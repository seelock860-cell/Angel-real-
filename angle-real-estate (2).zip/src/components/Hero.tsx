import React from 'react';
import { Search, MapPin, Home, Bed, MessageCircle, ArrowRight, CheckCircle2 } from 'lucide-react';
import { PropertyFilterState } from '../types/property';
import { PROPERTY_TYPES, POPULAR_LOCATIONS } from '../data/initialProperties';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_NUMBER } from '../lib/whatsapp';

interface HeroProps {
  filter: PropertyFilterState;
  onFilterChange: (updates: Partial<PropertyFilterState>) => void;
  onSearchSubmit: () => void;
  onExploreClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  filter,
  onFilterChange,
  onSearchSubmit,
  onExploreClick
}) => {
  return (
    <section className="relative min-h-[640px] lg:min-h-[720px] flex items-center justify-center text-white overflow-hidden">
      {/* Background Hero Image with Elegant Architectural Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_angle_property_1793350587000.jpg"
          alt="Angle Real Estate Luxury Property"
          className="w-full h-full object-cover object-center scale-105 transform motion-safe:animate-[pulse_10s_ease-in-out_infinite]"
        />
        {/* Deep blue + Charcoal overlay scrim ensuring 4.5:1 text contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/75 to-blue-950/60" />
      </div>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 w-full flex flex-col items-center text-center">
        {/* Subtle Brand Tag */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-900/40 border border-blue-400/30 backdrop-blur-md text-blue-200 text-xs font-semibold uppercase tracking-wider mb-6">
          <span className="w-2 h-2 rounded-full bg-blue-400" />
          <span>Angle Real Estate · Lagos & Abuja</span>
        </div>

        {/* Primary Headline as required */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight max-w-4xl font-sans text-balance leading-tight sm:leading-none text-white drop-shadow-sm mb-6">
          Find a Place to Call Home.
        </h1>

        {/* Short Company Introduction */}
        <p className="text-base sm:text-lg md:text-xl text-slate-200 max-w-2xl leading-relaxed font-normal mb-8 text-balance">
          Angle Real Estate is your premier property partner for buying, selling, and renting luxury residential villas, penthouses, and prime commercial developments across Nigeria.
        </p>

        {/* Dual Primary Call to Actions */}
        <div className="flex flex-col sm:flex-row items-center gap-4 mb-12 w-full sm:w-auto">
          <button
            onClick={onExploreClick}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg shadow-lg shadow-blue-900/30 transition-all cursor-pointer group"
          >
            <span>Explore Properties</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <a
            href={getWhatsAppUrl("Hello Angle Real Estate, I would like to consult with an agent regarding property acquisition.")}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 bg-white/10 hover:bg-white/20 text-white border border-white/30 backdrop-blur-md font-semibold rounded-lg transition-all cursor-pointer"
          >
            <MessageCircle className="w-5 h-5 text-emerald-400" />
            <span>Chat on WhatsApp</span>
          </a>
        </div>

        {/* Trust Badges Bar */}
        <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs sm:text-sm text-slate-300 mb-10">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-400" />
            <span>100% Verified Titles</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-400" />
            <span>Zero Brokerage Hidden Fees</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-400" />
            <span>Immediate WhatsApp Support</span>
          </div>
        </div>

        {/* Quick Property Search Console */}
        <div className="w-full max-w-4xl bg-white text-slate-900 rounded-2xl shadow-2xl p-4 sm:p-6 border border-slate-100">
          {/* Top Segmented Listing Type Bar */}
          <div className="flex items-center gap-2 border-b border-slate-100 pb-4 mb-4">
            <button
              onClick={() => onFilterChange({ listing_type: 'all' })}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-all cursor-pointer ${
                filter.listing_type === 'all'
                  ? 'bg-blue-700 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              All Listings
            </button>
            <button
              onClick={() => onFilterChange({ listing_type: 'buy' })}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-all cursor-pointer ${
                filter.listing_type === 'buy'
                  ? 'bg-blue-700 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Buy Property
            </button>
            <button
              onClick={() => onFilterChange({ listing_type: 'rent' })}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-all cursor-pointer ${
                filter.listing_type === 'rent'
                  ? 'bg-blue-700 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Rent Property
            </button>
          </div>

          {/* Form Search Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-left">
            {/* Location Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-blue-600" />
                <span>Location</span>
              </label>
              <select
                value={filter.search}
                onChange={(e) => onFilterChange({ search: e.target.value === 'All Locations' ? '' : e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-xs sm:text-sm rounded-lg p-2.5 focus:ring-2 focus:ring-blue-600 focus:outline-none"
              >
                {POPULAR_LOCATIONS.map((loc) => (
                  <option key={loc} value={loc === 'All Locations' ? '' : loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>

            {/* Property Type */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1 flex items-center gap-1.5">
                <Home className="w-3.5 h-3.5 text-blue-600" />
                <span>Property Type</span>
              </label>
              <select
                value={filter.property_type}
                onChange={(e) => onFilterChange({ property_type: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-xs sm:text-sm rounded-lg p-2.5 focus:ring-2 focus:ring-blue-600 focus:outline-none"
              >
                {PROPERTY_TYPES.map((type) => (
                  <option key={type} value={type === 'All Types' ? '' : type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>

            {/* Bedrooms */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1 flex items-center gap-1.5">
                <Bed className="w-3.5 h-3.5 text-blue-600" />
                <span>Bedrooms</span>
              </label>
              <select
                value={filter.bedrooms}
                onChange={(e) => {
                  const val = e.target.value;
                  onFilterChange({ bedrooms: val === 'all' ? 'all' : Number(val) });
                }}
                className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-xs sm:text-sm rounded-lg p-2.5 focus:ring-2 focus:ring-blue-600 focus:outline-none"
              >
                <option value="all">Any Bedrooms</option>
                <option value="1">1+ Bedroom</option>
                <option value="2">2+ Bedrooms</option>
                <option value="3">3+ Bedrooms</option>
                <option value="4">4+ Bedrooms</option>
                <option value="5">5+ Bedrooms</option>
              </select>
            </div>

            {/* Search Submit Button */}
            <div className="flex items-end">
              <button
                onClick={onSearchSubmit}
                className="w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg p-2.5 transition-colors cursor-pointer h-[42px]"
              >
                <Search className="w-4 h-4" />
                <span>Search</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
