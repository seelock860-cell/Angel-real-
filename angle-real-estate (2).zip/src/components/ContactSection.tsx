import React, { useState } from 'react';
import { MessageCircle, Phone, Mail, MapPin, Clock, Send, CheckCircle2, ShieldCheck } from 'lucide-react';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_NUMBER, WHATSAPP_RAW_NUMBER } from '../lib/whatsapp';
import { submitEnquiry } from '../lib/supabase';

export const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [propertyInterest, setPropertyInterest] = useState('General Enquiry');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    setIsSubmitting(true);
    try {
      await submitEnquiry({
        customer_name: name,
        customer_email: email || 'Not provided',
        customer_phone: phone,
        property_title: propertyInterest,
        message: message || `General enquiry regarding ${propertyInterest}`
      });
      setIsSent(true);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const directWhatsAppUrl = getWhatsAppUrl(
    `Hello Angle Real Estate,\n\nMy name is ${name || 'a prospective client'}.\nI would like to enquire about: ${propertyInterest}.\nPhone: ${phone || 'Not provided'}\n\nPlease get in touch with me.`
  );

  return (
    <section id="contact" className="py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-semibold uppercase tracking-wider mb-3">
            <span>Get in Touch</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Connect With Angle Real Estate
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-3 leading-relaxed">
            Our luxury advisory desk is available 7 days a week. Connect instantly via WhatsApp or submit your detailed property enquiry below.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Direct Contact Information & WhatsApp Quick Callout */}
          <div className="lg:col-span-5 space-y-6">
            {/* Primary WhatsApp Card (Highlighted) */}
            <div className="bg-gradient-to-br from-blue-900 to-slate-950 text-white rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden border border-blue-800">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl" />

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <MessageCircle className="w-6 h-6 fill-emerald-500/20" />
                </div>
                <div>
                  <span className="text-xs uppercase tracking-wider text-emerald-400 font-bold block">
                    Instant WhatsApp Concierge
                  </span>
                  <h3 className="text-lg font-bold text-white">Direct Agent Chat</h3>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 mb-6 leading-relaxed">
                Connect with our senior property advisors directly on WhatsApp for instantaneous photo catalogues, title documents, and priority physical viewing bookings.
              </p>

              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 mb-6">
                <div className="text-xs text-slate-400 mb-1">WhatsApp Direct Line:</div>
                <div className="text-xl sm:text-2xl font-black text-white tracking-wide tabular-nums font-mono">
                  {WHATSAPP_DISPLAY_NUMBER}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">Local format: {WHATSAPP_RAW_NUMBER}</div>
              </div>

              <a
                href={getWhatsAppUrl("Hello Angle Real Estate, I would like to make an enquiry regarding available properties.")}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all cursor-pointer group"
              >
                <MessageCircle className="w-5 h-5 fill-white/20" />
                <span>Open WhatsApp Chat Now</span>
              </a>
            </div>

            {/* Corporate Location Details */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs space-y-4 text-xs sm:text-sm">
              <div className="flex items-start gap-3 text-slate-700">
                <MapPin className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-slate-900 font-semibold">Headquarters:</strong>
                  <span>Admiralty Way, Lekki Phase 1, Lagos, Nigeria</span>
                  <span className="block text-xs text-slate-500 mt-0.5">
                    Branch Office: Maitama District, Abuja FCT
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3 text-slate-700 pt-3 border-t border-slate-100">
                <Phone className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-slate-900 font-semibold">Telephone & WhatsApp:</strong>
                  <a href={`tel:${WHATSAPP_RAW_NUMBER}`} className="hover:text-blue-700">
                    {WHATSAPP_RAW_NUMBER} / {WHATSAPP_DISPLAY_NUMBER}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 text-slate-700 pt-3 border-t border-slate-100">
                <Mail className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-slate-900 font-semibold">Direct Advisory Email:</strong>
                  <a href="mailto:info@anglerealestate.com" className="hover:text-blue-700">
                    info@anglerealestate.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 text-slate-700 pt-3 border-t border-slate-100">
                <Clock className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-slate-900 font-semibold">Working Hours:</strong>
                  <span>Monday – Saturday: 8:00 AM – 7:00 PM</span>
                  <span className="block text-xs text-slate-500 mt-0.5">
                    Sunday: By Private Viewing Appointment Only
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Property Enquiry Form */}
          <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-sm">
            <h3 className="text-xl font-bold text-slate-900 mb-2">Send Us an Enquiry</h3>
            <p className="text-xs sm:text-sm text-slate-600 mb-6">
              Fill out the form below with your property requirements, budget, or inspection schedule.
            </p>

            {isSent ? (
              <div className="py-10 text-center space-y-4">
                <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto" />
                <h4 className="text-xl font-bold text-slate-900">Enquiry Dispatched Successfully!</h4>
                <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
                  Thank you for contacting Angle Real Estate. A dedicated property agent will call or message you on <strong>{phone}</strong> shortly.
                </p>

                <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                  <a
                    href={directWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-sm"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Also Send to WhatsApp ({WHATSAPP_DISPLAY_NUMBER})</span>
                  </a>

                  <button
                    onClick={() => {
                      setIsSent(false);
                      setMessage('');
                    }}
                    className="px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-medium rounded-lg"
                  >
                    Submit Another Request
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Adebayo Adeleke"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Phone Number / WhatsApp *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 09023971419"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Email Address
                    </label>
                    <input
                      type="email"
                      placeholder="e.g. adebayo@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Service / Property Interest
                    </label>
                    <select
                      value={propertyInterest}
                      onChange={(e) => setPropertyInterest(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    >
                      <option value="Buying Luxury Property">Buying Luxury Property</option>
                      <option value="Renting / Leasing Residence">Renting / Leasing Residence</option>
                      <option value="Selling a Property">Selling a Property</option>
                      <option value="Commercial Office Space">Commercial Office Space</option>
                      <option value="Off-Market Private Inspection">Off-Market Private Inspection</option>
                      <option value="General Consultation">General Consultation</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Your Requirements & Message
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Tell us what you are looking for (preferred location, budget, number of bedrooms, desired move-in date)..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <span className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Your privacy and contact details are strictly confidential.</span>
                  </span>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3 bg-blue-700 hover:bg-blue-600 text-white font-semibold text-xs sm:text-sm rounded-lg shadow-sm transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isSubmitting ? 'Submitting...' : 'Send Enquiry'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
