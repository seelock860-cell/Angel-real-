import React, { useState, useEffect } from 'react';
import { 
  X, Building2, Plus, Trash2, Edit3, CheckCircle2, AlertCircle, 
  MessageCircle, RefreshCw, Database, Copy, Check, 
  ExternalLink, Search, Tag, KeyRound, Layers, ShieldCheck
} from 'lucide-react';
import { Property, Enquiry, PropertyStatus, ListingType, PropertyCategory } from '../types/property';
import { 
  getSavedSupabaseConfig, 
  updateSupabaseConfig, 
  testSupabaseConnection, 
  isSupabaseConfigured,
  getSupabaseClient,
  saveProperty,
  deleteProperty,
  updateEnquiryStatus,
  seedPropertiesToSupabase,
  resetToSampleProperties
} from '../lib/supabase';
import { getClientReplyWhatsAppUrl } from '../lib/whatsapp';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  properties: Property[];
  enquiries: Enquiry[];
  onRefreshData: () => Promise<void>;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  isOpen,
  onClose,
  properties,
  enquiries,
  onRefreshData
}) => {
  if (!isOpen) return null;

  // Active Tab: 'properties' | 'enquiries' | 'supabase'
  const [activeTab, setActiveTab] = useState<'properties' | 'enquiries' | 'supabase'>('properties');

  // Supabase Configuration Form
  const savedConfig = getSavedSupabaseConfig();
  const [supabaseUrl, setSupabaseUrl] = useState(savedConfig.url);
  const [supabaseKey, setSupabaseKey] = useState(savedConfig.anonKey);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  // Property Search / Filter in Table
  const [tableSearch, setTableSearch] = useState('');

  // Add / Edit Property Modal State
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [propertyForm, setPropertyForm] = useState<Partial<Property>>({
    title: '',
    description: '',
    price: 150000000,
    currency: '₦',
    location: 'Lekki Phase 1, Lagos',
    city: 'Lekki',
    state: 'Lagos',
    listing_type: 'buy',
    property_type: 'Duplex',
    bedrooms: 4,
    bathrooms: 4,
    area_sqm: 450,
    images: ['/src/assets/images/villa_lekki_facade_1793350588492.jpg'],
    featured: false,
    status: 'available',
    features: ['24/7 Security', 'CCTV Monitored', 'Fitted Kitchen', 'Ample Parking']
  });

  const [newFeatureText, setNewFeatureText] = useState('');
  const [imageUrlInput, setImageUrlInput] = useState('');

  // Supabase Config Handlers
  const handleSaveSupabaseConfig = () => {
    const res = updateSupabaseConfig(supabaseUrl, supabaseKey);
    setTestResult(res);
    onRefreshData();
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await testSupabaseConnection(supabaseUrl, supabaseKey);
      setTestResult(res);
    } catch (err: any) {
      setTestResult({ success: false, message: err.message });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSyncToSupabase = async () => {
    setIsSyncing(true);
    setSyncStatus(null);
    try {
      const res = await seedPropertiesToSupabase();
      if (res.success) {
        setSyncStatus(`Successfully synchronized ${res.count} properties to Supabase database!`);
        await onRefreshData();
      } else {
        setSyncStatus(`Sync error: ${res.error}`);
      }
    } catch (err: any) {
      setSyncStatus(`Sync failed: ${err.message}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleCopySql = () => {
    const sqlText = `-- ANGLE REAL ESTATE SUPABASE SCHEMA
CREATE TABLE IF NOT EXISTS public.properties (
    id TEXT PRIMARY KEY DEFAULT ('prop-' || substr(md5(random()::text), 1, 12)),
    title TEXT NOT NULL,
    description TEXT,
    price NUMERIC NOT NULL,
    currency TEXT DEFAULT '₦',
    location TEXT NOT NULL,
    city TEXT,
    state TEXT,
    listing_type TEXT NOT NULL CHECK (listing_type IN ('buy', 'rent', 'sell')),
    property_type TEXT NOT NULL,
    bedrooms INTEGER DEFAULT 0,
    bathrooms INTEGER DEFAULT 0,
    area_sqm NUMERIC DEFAULT 0,
    images JSONB DEFAULT '[]'::jsonb,
    features JSONB DEFAULT '[]'::jsonb,
    featured BOOLEAN DEFAULT FALSE,
    status TEXT DEFAULT 'available' CHECK (status IN ('available', 'reserved', 'sold')),
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

CREATE TABLE IF NOT EXISTS public.enquiries (
    id TEXT PRIMARY KEY DEFAULT ('enq-' || substr(md5(random()::text), 1, 12)),
    property_id TEXT,
    property_title TEXT,
    customer_name TEXT NOT NULL,
    customer_email TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'closed')),
    created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enquiries ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'properties' AND policyname = 'Public can view properties') THEN
        CREATE POLICY "Public can view properties" ON public.properties FOR SELECT USING (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'properties' AND policyname = 'Allow admin dashboard to manage properties') THEN
        CREATE POLICY "Allow admin dashboard to manage properties" ON public.properties FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'enquiries' AND policyname = 'Public can submit enquiries') THEN
        CREATE POLICY "Public can submit enquiries" ON public.enquiries FOR INSERT WITH CHECK (true);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'enquiries' AND policyname = 'Allow dashboard to manage enquiries') THEN
        CREATE POLICY "Allow dashboard to manage enquiries" ON public.enquiries FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
    END IF;
END
$$;
`;
    navigator.clipboard.writeText(sqlText);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  // Property Actions
  const openAddProperty = () => {
    setEditingProperty(null);
    setPropertyForm({
      id: `prop-${Date.now()}`,
      title: '',
      description: '',
      price: 250000000,
      currency: '₦',
      location: 'Lekki Phase 1, Lagos',
      city: 'Lekki',
      state: 'Lagos',
      listing_type: 'buy',
      property_type: 'Duplex',
      bedrooms: 4,
      bathrooms: 4,
      area_sqm: 450,
      images: ['/src/assets/images/villa_lekki_facade_1793350588492.jpg'],
      featured: false,
      status: 'available',
      features: ['24/7 Security', 'CCTV Monitored', 'Fitted Kitchen', 'Ample Parking'],
      created_at: new Date().toISOString()
    });
    setIsAddModalOpen(true);
  };

  const openEditProperty = (prop: Property) => {
    setEditingProperty(prop);
    setPropertyForm({ ...prop });
    setIsAddModalOpen(true);
  };

  const handleSavePropertyForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!propertyForm.title || !propertyForm.price || !propertyForm.location) {
      alert('Please fill in title, price, and location.');
      return;
    }

    setIsSaving(true);
    try {
      const payload: Property = {
        id: editingProperty ? editingProperty.id : `prop-${Date.now()}`,
        title: propertyForm.title || 'Untitled Property',
        description: propertyForm.description || '',
        price: Number(propertyForm.price),
        currency: propertyForm.currency || '₦',
        location: propertyForm.location || 'Lagos, Nigeria',
        city: propertyForm.city || 'Lagos',
        state: propertyForm.state || 'Lagos',
        listing_type: (propertyForm.listing_type as ListingType) || 'buy',
        property_type: (propertyForm.property_type as PropertyCategory) || 'Duplex',
        bedrooms: Number(propertyForm.bedrooms) || 0,
        bathrooms: Number(propertyForm.bathrooms) || 0,
        area_sqm: Number(propertyForm.area_sqm) || 0,
        images: propertyForm.images && propertyForm.images.length > 0 
          ? propertyForm.images 
          : ['/src/assets/images/hero_angle_property_1793350587000.jpg'],
        featured: Boolean(propertyForm.featured),
        status: (propertyForm.status as PropertyStatus) || 'available',
        features: propertyForm.features || [],
        created_at: editingProperty ? editingProperty.created_at : new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      await saveProperty(payload);
      await onRefreshData();
      setIsAddModalOpen(false);
    } catch (err: any) {
      alert(`Error saving property: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string, title: string) => {
    if (window.confirm(`Are you sure you want to permanently delete "${title}"?`)) {
      await deleteProperty(id);
      await onRefreshData();
    }
  };

  const handleStatusChange = async (property: Property, newStatus: PropertyStatus) => {
    await saveProperty({
      ...property,
      status: newStatus
    });
    await onRefreshData();
  };

  const handleEnquiryStatusChange = async (enquiryId: string, status: 'new' | 'contacted' | 'closed') => {
    await updateEnquiryStatus(enquiryId, status);
    await onRefreshData();
  };

  // Handle local image file upload
  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setPropertyForm(prev => ({
            ...prev,
            images: [reader.result as string, ...(prev.images || [])]
          }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Metrics
  const totalProperties = properties.length;
  const forSaleCount = properties.filter(p => p.listing_type === 'buy').length;
  const forRentCount = properties.filter(p => p.listing_type === 'rent').length;
  const totalValuation = properties.reduce((acc, curr) => acc + (curr.price || 0), 0);
  const newEnquiriesCount = enquiries.filter(e => e.status === 'new').length;

  const filteredProperties = properties.filter(p => 
    p.title.toLowerCase().includes(tableSearch.toLowerCase()) ||
    p.location.toLowerCase().includes(tableSearch.toLowerCase()) ||
    p.property_type.toLowerCase().includes(tableSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex flex-col overflow-hidden">
      {/* Top Admin Header Bar */}
      <header className="bg-slate-900 border-b border-slate-800 text-white px-6 py-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-sm">
            A
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>ANGLE REAL ESTATE</span>
              <span className="text-xs font-normal px-2 py-0.5 rounded bg-blue-950 border border-blue-800 text-blue-300">
                Admin Console
              </span>
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>Executive Management</span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <span className={`w-2 h-2 rounded-full ${isSupabaseConfigured() ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                {isSupabaseConfigured() ? 'Supabase Live' : 'Local Storage Mode'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close Dashboard"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto bg-slate-950 p-4 sm:p-6 text-slate-100">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Top Metrics Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs text-slate-400 block mb-1">Total Properties</span>
                  <div className="text-2xl font-black text-white tabular-nums">{totalProperties}</div>
                  <span className="text-[11px] text-blue-400">In Active Catalog</span>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs text-slate-400 block mb-1">For Sale (Buy)</span>
                  <div className="text-2xl font-black text-emerald-400 tabular-nums">{forSaleCount}</div>
                  <span className="text-[11px] text-slate-500">Villas & Duplexes</span>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs text-slate-400 block mb-1">For Rent</span>
                  <div className="text-2xl font-black text-cyan-400 tabular-nums">{forRentCount}</div>
                  <span className="text-[11px] text-slate-500">Annual Leases</span>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                  <span className="text-xs text-slate-400 block mb-1">New Enquiries</span>
                  <div className="text-2xl font-black text-amber-400 tabular-nums">{newEnquiriesCount}</div>
                  <span className="text-[11px] text-slate-500">{enquiries.length} total leads</span>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl col-span-2 lg:col-span-1">
                  <span className="text-xs text-slate-400 block mb-1">Portfolio Value</span>
                  <div className="text-lg font-black text-white truncate tabular-nums">
                    ₦{(totalValuation / 1000000).toLocaleString()}M
                  </div>
                  <span className="text-[11px] text-slate-500">Cumulative Listing</span>
                </div>
              </div>

              {/* Navigation Tabs */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setActiveTab('properties')}
                    className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-2 ${
                      activeTab === 'properties' 
                        ? 'bg-blue-600 text-white' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    <span>Properties Catalog ({totalProperties})</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('enquiries')}
                    className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-2 ${
                      activeTab === 'enquiries' 
                        ? 'bg-blue-600 text-white' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900'
                    }`}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Customer Enquiries ({enquiries.length})</span>
                    {newEnquiriesCount > 0 && (
                      <span className="px-1.5 py-0.2 bg-amber-500 text-slate-950 font-black text-[10px] rounded-full">
                        {newEnquiriesCount}
                      </span>
                    )}
                  </button>

                  <button
                    onClick={() => setActiveTab('supabase')}
                    className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-2 ${
                      activeTab === 'supabase' 
                        ? 'bg-blue-600 text-white' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-900'
                    }`}
                  >
                    <Database className="w-4 h-4" />
                    <span>Supabase Integration</span>
                  </button>
                </div>

                <button
                  onClick={onRefreshData}
                  className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors text-xs flex items-center gap-1 cursor-pointer"
                  title="Refresh Data"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span className="hidden sm:inline">Refresh</span>
                </button>
              </div>

              {/* TAB 1: PROPERTIES CATALOG */}
              {activeTab === 'properties' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="relative flex-1 max-w-md">
                      <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                      <input
                        type="text"
                        placeholder="Search properties by title, location, type..."
                        value={tableSearch}
                        onChange={(e) => setTableSearch(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={openAddProperty}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Upload New Property</span>
                      </button>

                      <button
                        onClick={() => {
                          if (window.confirm('Restore initial 5 luxury properties?')) {
                            resetToSampleProperties();
                            onRefreshData();
                          }
                        }}
                        className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium rounded-lg border border-slate-800"
                        title="Reset to default luxury portfolio"
                      >
                        Reset Demo
                      </button>
                    </div>
                  </div>

                  {/* Properties Table */}
                  <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                          <tr>
                            <th className="py-3 px-4">Property</th>
                            <th className="py-3 px-4">Type / Intent</th>
                            <th className="py-3 px-4">Price (₦)</th>
                            <th className="py-3 px-4">Specs</th>
                            <th className="py-3 px-4">Availability</th>
                            <th className="py-3 px-4 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 text-slate-300">
                          {filteredProperties.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="py-8 text-center text-slate-500">
                                No properties found matching your search.
                              </td>
                            </tr>
                          ) : (
                            filteredProperties.map((prop) => (
                              <tr key={prop.id} className="hover:bg-slate-800/40 transition-colors">
                                <td className="py-3 px-4">
                                  <div className="flex items-center gap-3">
                                    <img
                                      src={prop.images?.[0] || '/src/assets/images/hero_angle_property_1793350587000.jpg'}
                                      alt={prop.title}
                                      className="w-12 h-10 object-cover rounded-md bg-slate-800 shrink-0 border border-slate-700"
                                    />
                                    <div className="max-w-xs">
                                      <span className="font-bold text-white block truncate">{prop.title}</span>
                                      <span className="text-[11px] text-slate-400 truncate block">{prop.location}</span>
                                    </div>
                                  </div>
                                </td>

                                <td className="py-3 px-4">
                                  <span className="capitalize font-medium text-white">{prop.property_type}</span>
                                  <span className="text-[11px] text-slate-400 block uppercase">
                                    For {prop.listing_type}
                                  </span>
                                </td>

                                <td className="py-3 px-4 font-bold text-white tabular-nums">
                                  {prop.currency}{prop.price.toLocaleString()}
                                  {prop.listing_type === 'rent' && <span className="text-[10px] text-slate-400">/yr</span>}
                                </td>

                                <td className="py-3 px-4 text-slate-400">
                                  {prop.bedrooms} beds · {prop.bathrooms} baths
                                  <span className="block text-[11px]">{prop.area_sqm} m²</span>
                                </td>

                                <td className="py-3 px-4">
                                  <select
                                    value={prop.status}
                                    onChange={(e) => handleStatusChange(prop, e.target.value as PropertyStatus)}
                                    className={`px-2 py-1 rounded text-xs font-semibold border focus:outline-none cursor-pointer ${
                                      prop.status === 'available'
                                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                                        : prop.status === 'reserved'
                                        ? 'bg-amber-950/80 text-amber-300 border-amber-800'
                                        : 'bg-rose-950/80 text-rose-300 border-rose-800'
                                    }`}
                                  >
                                    <option value="available">Available</option>
                                    <option value="reserved">Reserved</option>
                                    <option value="sold">Sold</option>
                                  </select>
                                </td>

                                <td className="py-3 px-4 text-right">
                                  <div className="flex items-center justify-end gap-1.5">
                                    <button
                                      onClick={() => openEditProperty(prop)}
                                      className="p-1.5 text-slate-400 hover:text-blue-400 hover:bg-slate-800 rounded transition-colors"
                                      title="Edit Property Details"
                                    >
                                      <Edit3 className="w-4 h-4" />
                                    </button>
                                    <button
                                      onClick={() => handleDelete(prop.id, prop.title)}
                                      className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
                                      title="Delete Property"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: CUSTOMER ENQUIRIES & LEADS */}
              {activeTab === 'enquiries' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-slate-400">
                      Incoming leads and inspection requests from customers across website and property cards.
                    </p>
                    <span className="text-xs font-semibold text-slate-300">
                      {enquiries.length} Total Enquiries
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {enquiries.length === 0 ? (
                      <div className="col-span-2 py-12 text-center text-slate-500 bg-slate-900 rounded-xl border border-slate-800">
                        No customer enquiries recorded yet.
                      </div>
                    ) : (
                      enquiries.map((enq) => (
                        <div key={enq.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <div className="flex items-center gap-2">
                                <h4 className="text-sm font-bold text-white">{enq.customer_name}</h4>
                                <span className={`px-2 py-0.5 text-[10px] uppercase font-bold rounded ${
                                  enq.status === 'new' 
                                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' 
                                    : enq.status === 'contacted'
                                    ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                }`}>
                                  {enq.status}
                                </span>
                              </div>
                              <span className="text-xs text-slate-400">{enq.customer_phone} · {enq.customer_email}</span>
                            </div>

                            <span className="text-[10px] text-slate-500">
                              {new Date(enq.created_at).toLocaleDateString()}
                            </span>
                          </div>

                          {enq.property_title && (
                            <div className="text-xs bg-slate-950 p-2.5 rounded-lg border border-slate-800/80">
                              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Interested Property</span>
                              <span className="font-semibold text-blue-300">{enq.property_title}</span>
                            </div>
                          )}

                          <div className="text-xs text-slate-300 bg-slate-800/40 p-3 rounded-lg border border-slate-800">
                            {enq.message}
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] text-slate-400">Mark as:</span>
                              <select
                                value={enq.status}
                                onChange={(e) => handleEnquiryStatusChange(enq.id, e.target.value as any)}
                                className="bg-slate-800 border border-slate-700 text-xs text-slate-200 rounded px-2 py-1"
                              >
                                <option value="new">New</option>
                                <option value="contacted">Contacted</option>
                                <option value="closed">Closed</option>
                              </select>
                            </div>

                            <a
                              href={getClientReplyWhatsAppUrl(enq.customer_phone, enq.customer_name, enq.property_title)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm"
                            >
                              <MessageCircle className="w-3.5 h-3.5 fill-white/20" />
                              <span>Reply on WhatsApp</span>
                            </a>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* TAB 3: SUPABASE INTEGRATION */}
              {activeTab === 'supabase' && (
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Database className="w-5 h-5 text-blue-400" />
                      <span>Supabase Project Integration</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Connect your production Supabase database to persist properties, sync real-time changes, and handle client enquiries.
                    </p>
                  </div>

                  {/* Credentials Form */}
                  <div className="space-y-4 max-w-2xl bg-slate-950 p-5 rounded-xl border border-slate-800">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Supabase Project URL *
                      </label>
                      <input
                        type="url"
                        placeholder="https://your-project.supabase.co"
                        value={supabaseUrl}
                        onChange={(e) => setSupabaseUrl(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                      />
                      <span className="text-[11px] text-slate-500 mt-1 block">
                        Found in Supabase Dashboard &gt; Project Settings &gt; API
                      </span>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Supabase Publishable API Key (Anon / Public) *
                      </label>
                      <input
                        type="password"
                        placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                        value={supabaseKey}
                        onChange={(e) => setSupabaseKey(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                      />
                      <span className="text-[11px] text-slate-500 mt-1 block text-emerald-400">
                        Safe for frontend. Never use the service_role key.
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 pt-2">
                      <button
                        onClick={handleSaveSupabaseConfig}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
                      >
                        Save Configuration
                      </button>

                      <button
                        onClick={handleTestConnection}
                        disabled={isTesting}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-colors cursor-pointer disabled:opacity-50"
                      >
                        {isTesting ? 'Testing Connection...' : 'Test Connection'}
                      </button>

                      <button
                        onClick={handleSyncToSupabase}
                        disabled={isSyncing}
                        className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                      >
                        {isSyncing ? 'Synchronizing...' : 'Push Local Catalog to Supabase'}
                      </button>
                    </div>

                    {testResult && (
                      <div className={`p-3 rounded-lg text-xs flex items-start gap-2 ${
                        testResult.success 
                          ? 'bg-emerald-950/60 border border-emerald-800 text-emerald-300' 
                          : 'bg-rose-950/60 border border-rose-800 text-rose-300'
                      }`}>
                        {testResult.success ? (
                          <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                        ) : (
                          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                        )}
                        <span>{testResult.message}</span>
                      </div>
                    )}

                    {syncStatus && (
                      <div className="p-3 bg-blue-950/60 border border-blue-800 text-blue-300 text-xs rounded-lg">
                        {syncStatus}
                      </div>
                    )}
                  </div>

                  {/* SQL Schema Script Section */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <span>Database SQL Setup Script (`supabase_schema.sql`)</span>
                      </h4>
                      <button
                        onClick={handleCopySql}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 cursor-pointer"
                      >
                        {copiedSql ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedSql ? 'Copied SQL!' : 'Copy SQL Script'}</span>
                      </button>
                    </div>
                    <p className="text-xs text-slate-400">
                      Paste this SQL script directly into your Supabase Dashboard under <strong>SQL Editor &gt; New Query</strong>. It creates the <code>properties</code> and <code>enquiries</code> tables with Row Level Security (RLS) enabled.
                    </p>

                    <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-slate-300 font-mono text-[11px] overflow-x-auto max-h-48">
{`-- Execute in Supabase SQL Editor
CREATE TABLE IF NOT EXISTS public.properties (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    price NUMERIC NOT NULL,
    currency TEXT DEFAULT '₦',
    location TEXT NOT NULL,
    listing_type TEXT NOT NULL CHECK (listing_type IN ('buy', 'rent', 'sell')),
    property_type TEXT NOT NULL,
    bedrooms INTEGER DEFAULT 0,
    bathrooms INTEGER DEFAULT 0,
    area_sqm NUMERIC DEFAULT 0,
    images JSONB DEFAULT '[]'::jsonb,
    features JSONB DEFAULT '[]'::jsonb,
    featured BOOLEAN DEFAULT FALSE,
    status TEXT DEFAULT 'available',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view properties" ON public.properties FOR SELECT USING (true);
CREATE POLICY "Authenticated admin can manage properties" ON public.properties FOR ALL TO authenticated USING (true);
`}
                    </pre>
                  </div>
                </div>
              )}
        </div>
      </div>

      {/* ADD / EDIT PROPERTY MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-60 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col my-auto text-white">
            <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <h3 className="text-base font-bold text-white">
                {editingProperty ? `Edit Property: ${editingProperty.title}` : 'Upload New Property'}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePropertyForm} className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Property Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 5-Bedroom Luxury Smart Villa"
                  value={propertyForm.title || ''}
                  onChange={(e) => setPropertyForm(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Listing Type *</label>
                  <select
                    value={propertyForm.listing_type || 'buy'}
                    onChange={(e) => setPropertyForm(prev => ({ ...prev, listing_type: e.target.value as ListingType }))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none"
                  >
                    <option value="buy">For Sale (Buy)</option>
                    <option value="rent">For Rent</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Property Category *</label>
                  <select
                    value={propertyForm.property_type || 'Duplex'}
                    onChange={(e) => setPropertyForm(prev => ({ ...prev, property_type: e.target.value as PropertyCategory }))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none"
                  >
                    <option value="Villa">Villa</option>
                    <option value="Duplex">Duplex</option>
                    <option value="Penthouse">Penthouse</option>
                    <option value="Terrace">Terrace</option>
                    <option value="Apartment">Apartment</option>
                    <option value="Commercial">Commercial</option>
                    <option value="Land">Land</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Availability Status</label>
                  <select
                    value={propertyForm.status || 'available'}
                    onChange={(e) => setPropertyForm(prev => ({ ...prev, status: e.target.value as PropertyStatus }))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none"
                  >
                    <option value="available">Available</option>
                    <option value="reserved">Reserved</option>
                    <option value="sold">Sold</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Price (₦) *</label>
                  <input
                    type="number"
                    required
                    value={propertyForm.price || ''}
                    onChange={(e) => setPropertyForm(prev => ({ ...prev, price: Number(e.target.value) }))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500 tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Location Address *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Admiralty Way, Lekki Phase 1, Lagos"
                    value={propertyForm.location || ''}
                    onChange={(e) => setPropertyForm(prev => ({ ...prev, location: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Bedrooms</label>
                  <input
                    type="number"
                    min="0"
                    value={propertyForm.bedrooms ?? 0}
                    onChange={(e) => setPropertyForm(prev => ({ ...prev, bedrooms: Number(e.target.value) }))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Bathrooms</label>
                  <input
                    type="number"
                    min="0"
                    value={propertyForm.bathrooms ?? 0}
                    onChange={(e) => setPropertyForm(prev => ({ ...prev, bathrooms: Number(e.target.value) }))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Area (m²)</label>
                  <input
                    type="number"
                    min="0"
                    value={propertyForm.area_sqm ?? 0}
                    onChange={(e) => setPropertyForm(prev => ({ ...prev, area_sqm: Number(e.target.value) }))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none tabular-nums"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Description</label>
                <textarea
                  rows={3}
                  value={propertyForm.description || ''}
                  onChange={(e) => setPropertyForm(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Property Images Selection & Upload */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <label className="block text-slate-300 font-semibold">Property Pictures</label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    placeholder="Paste image URL (https://...)"
                    value={imageUrlInput}
                    onChange={(e) => setImageUrlInput(e.target.value)}
                    className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (imageUrlInput.trim()) {
                        setPropertyForm(prev => ({
                          ...prev,
                          images: [imageUrlInput.trim(), ...(prev.images || [])]
                        }));
                        setImageUrlInput('');
                      }
                    }}
                    className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium"
                  >
                    Add URL
                  </button>
                  <label className="px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer text-center font-medium">
                    <span>Upload File</span>
                    <input type="file" accept="image/*" onChange={handleImageFileUpload} className="hidden" />
                  </label>
                </div>

                {/* Quick Presets */}
                <div className="text-[11px] text-slate-400 flex items-center gap-2">
                  <span>Presets:</span>
                  <button
                    type="button"
                    onClick={() => setPropertyForm(p => ({ ...p, images: ['/src/assets/images/hero_angle_property_1793350587000.jpg', ...(p.images || [])] }))}
                    className="text-blue-400 hover:underline"
                  >
                    + Waterfront Villa
                  </button>
                  <button
                    type="button"
                    onClick={() => setPropertyForm(p => ({ ...p, images: ['/src/assets/images/villa_lekki_facade_1793350588492.jpg', ...(p.images || [])] }))}
                    className="text-blue-400 hover:underline"
                  >
                    + Luxury Duplex
                  </button>
                  <button
                    type="button"
                    onClick={() => setPropertyForm(p => ({ ...p, images: ['/src/assets/images/apartment_penthouse_1793350588439.jpg', ...(p.images || [])] }))}
                    className="text-blue-400 hover:underline"
                  >
                    + Penthouse
                  </button>
                  <button
                    type="button"
                    onClick={() => setPropertyForm(p => ({ ...p, images: ['/src/assets/images/commercial_office_tower_1793350589226.jpg', ...(p.images || [])] }))}
                    className="text-blue-400 hover:underline"
                  >
                    + Commercial Tower
                  </button>
                </div>

                {/* Current Images Preview */}
                <div className="flex items-center gap-2 overflow-x-auto py-2">
                  {(propertyForm.images || []).map((img, i) => (
                    <div key={i} className="relative w-20 h-16 rounded-lg overflow-hidden shrink-0 border border-slate-700">
                      <img src={img} alt="Property" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => {
                          setPropertyForm(prev => ({
                            ...prev,
                            images: (prev.images || []).filter((_, idx) => idx !== i)
                          }));
                        }}
                        className="absolute top-1 right-1 p-0.5 bg-rose-600 rounded text-white"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Features Tags */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <label className="block text-slate-300 font-semibold">Key Amenities</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g. Swimming Pool, Generator, Smart Automation"
                    value={newFeatureText}
                    onChange={(e) => setNewFeatureText(e.target.value)}
                    className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (newFeatureText.trim()) {
                        setPropertyForm(prev => ({
                          ...prev,
                          features: [...(prev.features || []), newFeatureText.trim()]
                        }));
                        setNewFeatureText('');
                      }
                    }}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg font-medium"
                  >
                    Add
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {(propertyForm.features || []).map((feat, i) => (
                    <span key={i} className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 text-slate-300 text-[11px]">
                      <span>{feat}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setPropertyForm(prev => ({
                            ...prev,
                            features: (prev.features || []).filter((_, idx) => idx !== i)
                          }));
                        }}
                        className="text-slate-400 hover:text-white"
                      >
                        &times;
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Featured Checkbox */}
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="featuredCheck"
                  checked={Boolean(propertyForm.featured)}
                  onChange={(e) => setPropertyForm(prev => ({ ...prev, featured: e.target.checked }))}
                  className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 bg-slate-800 border-slate-700"
                />
                <label htmlFor="featuredCheck" className="text-slate-300 font-semibold">
                  Pin as Marquee Featured Property on Homepage
                </label>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold shadow-sm transition-all disabled:opacity-50"
                >
                  {isSaving ? 'Saving...' : editingProperty ? 'Save Changes' : 'Publish Property'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
