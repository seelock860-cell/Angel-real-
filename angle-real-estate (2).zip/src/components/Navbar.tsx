import React, { useState } from 'react';
import { Building2, MessageCircle, ShieldCheck, Menu, X, PhoneCall } from 'lucide-react';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_NUMBER } from '../lib/whatsapp';

interface NavbarProps {
  onOpenAdmin?: () => void;
  onFilterChange: (type: 'all' | 'buy' | 'rent') => void;
  activeListingType: 'all' | 'buy' | 'rent';
  onNavigate: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onFilterChange,
  activeListingType,
  onNavigate
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (sectionId: string, filter?: 'all' | 'buy' | 'rent') => {
    if (filter) {
      onFilterChange(filter);
    }
    onNavigate(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all">
      {/* Top micro bar with contact & WhatsApp line */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 md:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-slate-300">
              <PhoneCall className="w-3.5 h-3.5 text-blue-400" />
              <span>Direct WhatsApp:</span>
              <a 
                href={getWhatsAppUrl()} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="font-semibold text-white hover:text-blue-300 transition-colors"
              >
                {WHATSAPP_DISPLAY_NUMBER}
              </a>
            </span>
            <span className="hidden sm:inline-block text-slate-500">·</span>
            <span className="hidden sm:inline-block text-slate-400">
              Licensed Real Estate Advisory · Lagos & Abuja
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-slate-400">
            <span>RC: 1849204</span>
          </div>
        </div>
      </div>

      {/* Main 3-Zone Navigation */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <button
          onClick={() => handleNavClick('hero')}
          className="flex items-center gap-3 text-left shrink-0 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-700 via-blue-800 to-slate-950 flex items-center justify-center text-white shadow-md shadow-blue-900/10 group-hover:scale-105 transition-transform">
            {/* Custom Angle Geometry Icon */}
            <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6 stroke-white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 21L21 21" />
              <path d="M3 21L3 5" />
              <path d="M3 5L21 21" />
              <circle cx="12" cy="12" r="1.5" fill="white" />
            </svg>
          </div>
          <div>
            <span className="font-extrabold tracking-tight text-xl text-slate-950 block leading-tight font-sans">
              ANGLE <span className="text-blue-700 font-bold">REAL ESTATE</span>
            </span>
            <span className="text-[10px] tracking-wider uppercase text-slate-500 block font-medium">
              Buy · Sell · Rent
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links (single line, clean text links) */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-700">
          <button
            onClick={() => handleNavClick('hero')}
            className="hover:text-blue-700 transition-colors whitespace-nowrap cursor-pointer py-1"
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('properties', 'all')}
            className={`transition-colors whitespace-nowrap cursor-pointer py-1 ${activeListingType === 'all' ? 'text-blue-700 font-semibold border-b-2 border-blue-700' : 'hover:text-blue-700'}`}
          >
            All Properties
          </button>
          <button
            onClick={() => handleNavClick('properties', 'buy')}
            className={`transition-colors whitespace-nowrap cursor-pointer py-1 ${activeListingType === 'buy' ? 'text-blue-700 font-semibold border-b-2 border-blue-700' : 'hover:text-blue-700'}`}
          >
            Buy
          </button>
          <button
            onClick={() => handleNavClick('properties', 'rent')}
            className={`transition-colors whitespace-nowrap cursor-pointer py-1 ${activeListingType === 'rent' ? 'text-blue-700 font-semibold border-b-2 border-blue-700' : 'hover:text-blue-700'}`}
          >
            Rent
          </button>
          <button
            onClick={() => handleNavClick('sell-section')}
            className="hover:text-blue-700 transition-colors whitespace-nowrap cursor-pointer py-1"
          >
            Sell With Us
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className="hover:text-blue-700 transition-colors whitespace-nowrap cursor-pointer py-1"
          >
            About Us
          </button>
          <button
            onClick={() => handleNavClick('contact')}
            className="hover:text-blue-700 transition-colors whitespace-nowrap cursor-pointer py-1"
          >
            Contact
          </button>
        </nav>

        {/* Zone 3: Primary Action (WhatsApp Enquiry) */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href={getWhatsAppUrl("Hello Angle Real Estate, I am looking to enquire about your available properties.")}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold rounded-lg shadow-sm hover:shadow transition-all whitespace-nowrap cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 text-white fill-white/20" />
            <span>Enquire on WhatsApp</span>
          </a>

          {/* Mobile hamburger toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-slate-700 hover:text-slate-900 rounded-lg hover:bg-slate-100"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-6 py-6 space-y-4 shadow-xl">
          <div className="flex flex-col space-y-3 text-base font-medium text-slate-800">
            <button
              onClick={() => handleNavClick('hero')}
              className="text-left py-2 hover:text-blue-700 border-b border-slate-100"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('properties', 'all')}
              className="text-left py-2 hover:text-blue-700 border-b border-slate-100"
            >
              All Properties
            </button>
            <button
              onClick={() => handleNavClick('properties', 'buy')}
              className="text-left py-2 hover:text-blue-700 border-b border-slate-100 text-blue-700 font-semibold"
            >
              Buy Properties
            </button>
            <button
              onClick={() => handleNavClick('properties', 'rent')}
              className="text-left py-2 hover:text-blue-700 border-b border-slate-100 text-blue-700 font-semibold"
            >
              Rent Properties
            </button>
            <button
              onClick={() => handleNavClick('sell-section')}
              className="text-left py-2 hover:text-blue-700 border-b border-slate-100"
            >
              Sell With Us (Property Owners)
            </button>
            <button
              onClick={() => handleNavClick('about')}
              className="text-left py-2 hover:text-blue-700 border-b border-slate-100"
            >
              About Angle Real Estate
            </button>
            <button
              onClick={() => handleNavClick('contact')}
              className="text-left py-2 hover:text-blue-700 border-b border-slate-100"
            >
              Contact & Location
            </button>
          </div>

          <div className="pt-2 flex flex-col gap-3">
            <a
              href={getWhatsAppUrl("Hello Angle Real Estate, I am looking to enquire about properties.")}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 bg-blue-700 text-white rounded-lg font-semibold text-sm"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp: {WHATSAPP_DISPLAY_NUMBER}</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
