export type ListingType = 'buy' | 'rent' | 'sell';

export type PropertyCategory = 
  | 'Villa'
  | 'Duplex'
  | 'Penthouse'
  | 'Terrace'
  | 'Apartment'
  | 'Commercial'
  | 'Land';

export type PropertyStatus = 'available' | 'reserved' | 'sold';

export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  location: string;
  city?: string;
  state?: string;
  listing_type: ListingType;
  property_type: PropertyCategory;
  bedrooms: number;
  bathrooms: number;
  area_sqm: number;
  images: string[];
  featured: boolean;
  status: PropertyStatus;
  features: string[];
  created_at: string;
  updated_at?: string;
}

export interface Enquiry {
  id: string;
  property_id?: string;
  property_title?: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  message: string;
  status: 'new' | 'contacted' | 'closed';
  created_at: string;
}

export interface PropertyFilterState {
  search: string;
  listing_type: 'all' | 'buy' | 'rent';
  property_type: string;
  bedrooms: number | 'all';
  max_price: number | 'all';
  sort_by: 'featured' | 'price-asc' | 'price-desc' | 'newest';
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
}
