import { Property } from '../types/property';

export const INITIAL_PROPERTIES: Property[] = [
  {
    id: 'prop-lekki-villa-01',
    title: 'The Obsidian Grand Waterfront Villa',
    description: 'An architectural masterpiece situated right along the Lekki coastline. This contemporary smart home features 5 palatial ensuite bedrooms, a private infinity pool overlooking the lagoon, floor-to-ceiling double-glazed thermal glass, Italian marble flooring, high-end automated security, and 2-room staff quarters.',
    price: 750000000,
    currency: '₦',
    location: 'Admiralty Way, Lekki Phase 1, Lagos',
    city: 'Lekki',
    state: 'Lagos',
    listing_type: 'buy',
    property_type: 'Villa',
    bedrooms: 5,
    bathrooms: 6,
    area_sqm: 780,
    images: [
      '/src/assets/images/hero_angle_property_1793350587000.jpg',
      '/src/assets/images/villa_lekki_facade_1793350588492.jpg'
    ],
    featured: true,
    status: 'available',
    features: [
      'Private Infinity Pool',
      'Lagoon Waterfront View',
      'Smart Home Automation',
      'Italian Marble Finishing',
      '2-Room BQ (Boys Quarters)',
      '24/7 Monitored CCTV',
      'Private Cinema Room',
      '4-Car Covered Carport'
    ],
    created_at: '2026-03-15T10:00:00Z'
  },
  {
    id: 'prop-banana-duplex-02',
    title: 'The Royal Horizon Luxury Duplex Mansion',
    description: 'Located in the most prestigious private enclave of Banana Island. Boasting timeless contemporary lines, triple-height foyer, custom chef kitchen with German appliances, temperature-controlled wine cellar, rooftop entertainment terrace, and biometric access controls.',
    price: 920000000,
    currency: '₦',
    location: 'Zone A, Banana Island, Ikoyi, Lagos',
    city: 'Ikoyi',
    state: 'Lagos',
    listing_type: 'buy',
    property_type: 'Duplex',
    bedrooms: 5,
    bathrooms: 6,
    area_sqm: 850,
    images: [
      '/src/assets/images/villa_lekki_facade_1793350588492.jpg',
      '/src/assets/images/hero_angle_property_1793350587000.jpg'
    ],
    featured: true,
    status: 'available',
    features: [
      'Gated High-Security Island',
      'Rooftop Lounge & Bar',
      'German Miele Appliances',
      'Wine Cellar',
      'Solar Power Inverter System',
      'Fitted Gym & Sauna',
      'Elevator / Lift',
      'Expansive Landscaped Garden'
    ],
    created_at: '2026-03-20T12:00:00Z'
  },
  {
    id: 'prop-vi-penthouse-03',
    title: 'Azure Sky Penthouse with Marina Panorama',
    description: 'An executive penthouse residence perched high above Victoria Island with unhindered 270-degree views of the Atlantic marina and Lagos city skyline. Features custom royal blue velvet designer appointments, open-concept entertainment lounge, master suite with spa-grade soak tub, and concierge service.',
    price: 45000000,
    currency: '₦',
    location: 'Ahmadu Bello Way, Victoria Island, Lagos',
    city: 'Victoria Island',
    state: 'Lagos',
    listing_type: 'rent',
    property_type: 'Penthouse',
    bedrooms: 4,
    bathrooms: 5,
    area_sqm: 480,
    images: [
      '/src/assets/images/apartment_penthouse_1793350588439.jpg'
    ],
    featured: true,
    status: 'available',
    features: [
      'Panoramic Marina View',
      'Concierge & Valet Service',
      'Private Keycard Elevator',
      'High-Speed Fiber Internet',
      'Central AC System',
      'Olympic-Sized Communal Pool',
      'Tennis & Squash Courts',
      '24/7 Uninterrupted Power'
    ],
    created_at: '2026-03-22T14:30:00Z'
  },
  {
    id: 'prop-maitama-terrace-04',
    title: 'The Grand Cedar Contemporary Terrace',
    description: 'A bespoke 4-bedroom luxury townhouse located in the diplomatic heart of Maitama, Abuja. Architectural highlights include natural cedar wood louvers, double volume dining area, solar energy backup, private manicured front lawn, and dedicated security post.',
    price: 380000000,
    currency: '₦',
    location: 'Mississippi Street, Maitama District, Abuja',
    city: 'Maitama',
    state: 'Abuja',
    listing_type: 'buy',
    property_type: 'Terrace',
    bedrooms: 4,
    bathrooms: 4,
    area_sqm: 390,
    images: [
      '/src/assets/images/suburban_residence_1793350589703.jpg'
    ],
    featured: false,
    status: 'available',
    features: [
      'Diplomatic Zone Security',
      'Solar Hybrid Power',
      'Cedar Architectural Louvers',
      'Fitted Gourmet Kitchen',
      'Private Walkway & Lawn',
      'Borehole & Water Filtration',
      'Integrated Audio System',
      'Dedicated Maid Suite'
    ],
    created_at: '2026-03-25T09:15:00Z'
  },
  {
    id: 'prop-vi-commercial-05',
    title: 'Axis One Prime Corporate Office Floor',
    description: 'Premier grade-A commercial office space in Victoria Island’s central business core. Features energy-efficient glass facade, flexible open layout ready for executive corporate partitioning, 4 high-speed destination lifts, full fire suppression, and fiber redundancy.',
    price: 65000000,
    currency: '₦',
    location: 'Adeola Odeku Street, Victoria Island, Lagos',
    city: 'Victoria Island',
    state: 'Lagos',
    listing_type: 'rent',
    property_type: 'Commercial',
    bedrooms: 0,
    bathrooms: 8,
    area_sqm: 1200,
    images: [
      '/src/assets/images/commercial_office_tower_1793350589226.jpg'
    ],
    featured: false,
    status: 'available',
    features: [
      'Grade-A Commercial Tower',
      '4 High-Speed Lifts',
      'Dual 1000kVA Diesel Generators',
      'Underground Dedicated Parking',
      'BMS (Building Management System)',
      'Fiber Optic Backbone',
      '24/7 Armed Security & CCTV',
      'LEED Silver Certified'
    ],
    created_at: '2026-03-28T16:00:00Z'
  }
];

export const PROPERTY_TYPES = [
  'All Types',
  'Villa',
  'Duplex',
  'Penthouse',
  'Terrace',
  'Apartment',
  'Commercial',
  'Land'
];

export const POPULAR_LOCATIONS = [
  'All Locations',
  'Lekki Phase 1, Lagos',
  'Banana Island, Ikoyi, Lagos',
  'Victoria Island, Lagos',
  'Ikoyi, Lagos',
  'Maitama District, Abuja',
  'Guzape, Abuja',
  'Ikeja GRA, Lagos'
];
